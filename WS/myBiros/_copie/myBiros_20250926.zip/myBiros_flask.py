###   I M P O R T   ###################################################

import base64
from datetime import datetime as dt
from datetime import timezone as tz
from flask import Flask, render_template, request, session
import locale
import myBiros
import os
from pathlib import Path
import sugarcrm as crm


###   L O G G E R   ###################################################

import logging
from logging.handlers import TimedRotatingFileHandler
import werkzeug

werkzeug.serving._log_add_style = False # no formattazione nei log

logger = logging.getLogger('werkzeug')
logger.setLevel(logging.DEBUG)

# 1. Handler per file rotanti giornalieri
file_handler = TimedRotatingFileHandler("myBiros_CRM.log", when="midnight", backupCount=30)
file_handler.suffix = "%Y%m%d"
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)

# 2. Handler per console
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(console_formatter)

# Evita doppie scritture
if not logger.handlers:
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)


###   C O S T A N T I   ###############################################

locale.setlocale(locale.LC_ALL, "it_IT")

# WS crm Agenti
url = "https://siglacredit.lionsolution.it/service/v4/rest.php"
usr = "edp"
pwd = "Edp2010$"

attachDir = "allegati" # cartella dove vengono salvati gli allegati del crm
Path(attachDir).mkdir(parents = True, exist_ok = True) # se non esiste, viene creata

TIPI_DOC = ["CAI", "BP", "OBIS"] # mappatura documenti su CRM (provvisoria)


###   F U N Z I O N I   ###############################################

def scaricaAllegatiContatto(id):
    try:
        s = crm.Session(url, usr, pwd)
        notes = s.get_entry_list(crm.Note(contact_id = id)) # tutte le note collegate al contatto
        files = []
        for note in notes:
            file = s.get_note_attachment(note)["note_attachment"] # allegato
            ext = os.path.splitext(file["filename"])[1][1:].lower() # estensione del file, senza punto e in minuscolo
            #with open(os.path.join(attachDir, file["filename"]), "wb") as f: f.write(base64.b64decode(file["file"])) # salva copia in locale
            files.append({"nome": note.name, "estensione": ext, "tipo": note.description, "b64": file["file"]})

        files = [f for f in files if f["tipo"] in TIPI_DOC] # tengo solo i documenti d'interesse
        return files
    except: return False

def analizzaDocumento(tipo, b64, estensione):
    if      tipo == "CAI":  return myBiros.estraiDatiDocumento_b64(b64, estensione)
    elif    tipo == "BP":   return myBiros.estraiDatiBustaPaga_b64(b64, estensione)
    elif    tipo == "OBIS": return myBiros.estraiDatiObisM_b64(b64, estensione)
    else:                   return False


###   M A I N   #######################################################

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or "you-will-never-guess" # provvisoria

@app.route('/', methods=['GET'])
def index(): 
    for key in ["id", "esito", "messaggio", "start"]: session.pop(key, None) # cancello i cookies
    session["start"] = dt.now(tz.utc) # data e ora della richiesta
    logger.info("SESSION: %s", session) # print dei cookies salvati, qui dovrebbe essere vuoto

    session["id"] = request.args.get("id") # recupero l'id del contatto dalla querystring
    return render_template("loading.html", title = "Analisi documenti")


@app.route('/result', methods=['GET'])
def result(): 
    logger.info("SESSION: %s", session) # cookies salvati
    return render_template("result.html", title = "Analisi documenti", esito = session["esito"], messaggio = session["messaggio"])


@app.route('/analizza', methods=['GET'])
def analizza():
    logger.info("SESSION: %s", session) # cookies salvati
    id = session["id"] # recupero l'id del contatto dai cookies

    documenti = scaricaAllegatiContatto(id)
    if documenti:
        output = []
        logger.info("DOCUMENTI SCARICATI: %s", len(documenti))
        for doc in documenti: 
            logger.info("%s: %s, %s", doc["nome"], doc["tipo"], doc["estensione"])
            dati = analizzaDocumento(doc["tipo"], doc["b64"], doc["estensione"])
            if dati: 
                logger.info("DATI ESTRATTI: %s", dati)
                output.append({doc["tipo"]: dati})
            else:  logger.warning("ERRORE NELL'ESTRAZIONE DATI O NESSUN DATO ESTRATTO")
        if output: 
            logger.info("OUTPUT: %s", output)
            session["esito"] = "Analizzato 1 documento" if len(output) == 1 else "Analizzati " + str(len(output)) + " documenti"
            session["messaggio"] = "Ricaricare la pagina del CRM per verificare i dati estratti."
        else: 
            logger.warning("DOCUMENTI SCARICATI MA NESSUN DATO ESTRATTO")
            session["esito"] = "Errore nell'estrazione dati o nessun dato estratto"
            session["messaggio"] = "Verificare i documenti presenti nel CRM e riprovare."
    
    else:
        logger.warning("NESSUN DOCUMENTO SCARICATO")
        session["esito"] = "Errore nel recupero dei documenti o nessun documento trovato"
        session["messaggio"] = "Verificare i documenti presenti nel CRM e riprovare."
    
    logger.info("TEMPO ELABORAZIONE: %s", str(dt.now(tz.utc) - session["start"])[:-5]) # calcolo tempo dalla richiesta iniziale
    return documenti


if __name__ == '__main__': app.run(host = "0.0.0.0", port = 7000) # ip e porta dove eseguire il web server