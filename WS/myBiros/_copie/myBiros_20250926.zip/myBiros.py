###   W S   M Y B I R O S   ###########################################
#
# Autore                Denis Cattai
# Ultima modifica       26/09/2025
# Versione Python       3.9.12
# Descrizione           Modulo per utilizzo WS myBiros
#
# Note                  Versione di produzione
#                       Sito web: https://platform.mybiros.com/home
#                       Utilizzare il sito per creare casi d'uso e
#                       associare Service ID e API Key per ognuno
#                       Doc: https://docs-platform.mybiros.com/v1
#


###   I M P O R T   ###################################################

import base64
import io
import mimetypes
import requests


###   C O S T A N T I   ###############################################

params = { # parametri delle chiamate API myBiros
    "include": ["service_fields"], # campi da includere nella risposta (ocr | service_fields | validation_errors)
    "document_details": "summary" # riassume i dati estratti da tutte le pagine del documento (pages | summary)
}

mimetype_file = { # mimetype dei file accettati (da file)
    "pdf":  "application/pdf",
    "png":  "image/png",
    "jpg":  "image/jpeg",
    "jpeg": "image/jpeg"
}

mimetype_b64 = { # mimetype dei file accettati (da base64)
    "JVBERi0":      "application/pdf",
    "iVBORw0KGgo":  "image/png",
    "/9j/":         "image/jpeg"
}


###   B U S T A   P A G A   ###########################################

def estraiDatiBustaPaga_file(file):
    """
    Estrae i dati presenti in una busta paga, a partire dal percorso del file.

    :param str file: percorso del file
    :return: list con le pensioni presenti nel documento, False in caso di errore
    """

    url = f"https://platform.mybiros.com/api/v1/inference/service/cb2f96d2-a8f2-4538-bba3-363c0b74a0d4/predict" # include il Service ID del caso d'uso
    headers = {"x-api-key": "oJBu6EAh--QZ450BuRY4WjvS1T57KP6YKkwv41wx", "Accept": "application/json"} # include l'API Key del caso d'uso

    with open(file, "rb") as f:
        files = {"file": (file, f, mimetypes.guess_type(file)[0]),"push_result_on_platform": (None, "never")}
        response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = []

        for field in response["service_fields"]:
            for entity in response["document_summary"]["entities"]:
                if field == entity and response["document_summary"]["entities"][entity]:
                    if type(response["document_summary"]["entities"][entity]) is list: # più valori, scelgo quello con confidence più alta
                        value = ""; confidence = 0
                        for e in response["document_summary"]["entities"][entity]:
                            if e["confidence"] > confidence: confidence = e["confidence"]; value = e["text"] # prendo il match con il valore di confidence più alto
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": value, "confidence": str(confidence)})
                    else: # unico valore, lo resetituisco
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": response["document_summary"]["entities"][entity]["text"], "confidence": str(response["document_summary"]["entities"][entity]["confidence"])})       
        return output
    else: return False

def estraiDatiBustaPaga_b64(b64, estensione):
    """
    Estrae i dati presenti in una busta paga, a partire da una stringa in base64.

    :param str b64: stringa base64 del file
    :param str estensione: estensione del file
    :return: list con le pensioni presenti nel documento, False in caso di errore
    """

    url = f"https://platform.mybiros.com/api/v1/inference/service/cb2f96d2-a8f2-4538-bba3-363c0b74a0d4/predict" # include il Service ID del caso d'uso
    headers = {"x-api-key": "oJBu6EAh--QZ450BuRY4WjvS1T57KP6YKkwv41wx", "Accept": "application/json"} # include l'API Key del caso d'uso

    file_bytes = base64.b64decode(b64) # creo un file virtuale a partire dal base64
    f = io.BytesIO(file_bytes)
    f.name = "documento." + estensione # necessario per farlo accettare come file

    files = {"file": (f.name, f, mimetype_file[estensione]),"push_result_on_platform": (None, "never")}
    response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = []
    
        for field in response["service_fields"]:
            for entity in response["document_summary"]["entities"]:
                if field == entity and response["document_summary"]["entities"][entity]:
                    if type(response["document_summary"]["entities"][entity]) is list: # più valori, scelgo quello con confidence più alta
                        value = ""; confidence = 0
                        for e in response["document_summary"]["entities"][entity]:
                            if e["confidence"] > confidence: confidence = e["confidence"]; value = e["text"] # prendo il match con il valore di confidence più alto
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": value, "confidence": str(confidence)})
                    else: # unico valore, lo resetituisco
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": response["document_summary"]["entities"][entity]["text"], "confidence": str(response["document_summary"]["entities"][entity]["confidence"])})       
        return output
    else: return False


###   D O C U M E N T I   D ' I D E N T I T A '   #####################

def estraiDatiDocumento_file(file):
    """
    Estrae i dati presenti in un set di documenti d'identità, a partire dal percorso del file.

    :param str file: percorso del file
    :return: list con le pensioni presenti nel documento, False in caso di errore
    """

    url = f"https://platform.mybiros.com/api/v1/inference/service/7471fd22-ee8d-4512-b77b-642dec127574/predict" # include il Service ID del caso d'uso
    headers = {"x-api-key": "CDtFLxF5SQ2geVwjMb8JQiUGVGgOeAUapz1fpc_4", "Accept": "application/json"} # include l'API Key del caso d'uso

    with open(file, "rb") as f:
        files = {"file": (file, f, mimetypes.guess_type(file)[0]),"push_result_on_platform": (None, "never")}
        response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = []
        
        for field in response["service_fields"]:
            for entity in response["document_summary"]["entities"]:
                if field == entity and response["document_summary"]["entities"][entity]:
                    if type(response["document_summary"]["entities"][entity]) is list: # più valori, scelgo quello con confidence più alta
                        value = ""; confidence = 0
                        for e in response["document_summary"]["entities"][entity]:
                            if e["confidence"] > confidence: confidence = e["confidence"]; value = e["text"] # prendo il match con il valore di confidence più alto
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": value, "confidence": str(confidence)})
                    else: # unico valore, lo resetituisco
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": response["document_summary"]["entities"][entity]["text"], "confidence": str(response["document_summary"]["entities"][entity]["confidence"])})       
        return output
    else: return False

def estraiDatiDocumento_b64(b64, estensione):
    """
    Estrae i dati presenti in un set di documenti d'identità, a partire da una stringa in base64.

    :param str b64: stringa base64 del file
    :param str estensione: estensione del file
    :return: list con le pensioni presenti nel documento, False in caso di errore
    """

    url = f"https://platform.mybiros.com/api/v1/inference/service/7471fd22-ee8d-4512-b77b-642dec127574/predict" # include il Service ID del caso d'uso
    headers = {"x-api-key": "CDtFLxF5SQ2geVwjMb8JQiUGVGgOeAUapz1fpc_4", "Accept": "application/json"} # include l'API Key del caso d'uso

    file_bytes = base64.b64decode(b64)
    f = io.BytesIO(file_bytes)
    f.name = "documento." + estensione # necessario per farlo accettare come file

    files = {"file": (f.name, f, mimetype_file[estensione]),"push_result_on_platform": (None, "never")}
    response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = []

        for field in response["service_fields"]:
            for entity in response["document_summary"]["entities"]:
                if field == entity and response["document_summary"]["entities"][entity]:
                    if type(response["document_summary"]["entities"][entity]) is list: # più valori, scelgo quello con confidence più alta
                        value = ""; confidence = 0
                        for e in response["document_summary"]["entities"][entity]:
                            if e["confidence"] > confidence: confidence = e["confidence"]; value = e["text"] # prendo il match con il valore di confidence più alto
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": value, "confidence": str(confidence)})
                    else: # unico valore, lo resetituisco
                        output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": response["document_summary"]["entities"][entity]["text"], "confidence": str(response["document_summary"]["entities"][entity]["confidence"])})       
        return output
    else: return False


###   O B I S   M   ###################################################

def estraiDatiObisM_file(file):
    """
    Estrae i dati presenti in un documento Obis M, a partire dal percorso del file.

    :param str file: percorso del file
    :return: list con le pensioni presenti nel documento, False in caso di errore
    """

    url = f"https://platform.mybiros.com/api/v1/inference/service/5f6f8a6c-ac77-4044-9ec7-eb491ef95f15/predict"
    headers = {"x-api-key": "7qdVqGJWylEEUAW4KY9HbWkd3AKJ2VKeTF8DTvcW", "Accept": "application/json"}

    params = { # parametri delle chiamate API myBiros
        "include": ["service_fields"], # campi da includere nella risposta
        "document_details": "pages" # output diviso per pagina
    }

    with open(file, "rb") as f:
        files = {"file": (file, f, mimetypes.guess_type(file)[0]),"push_result_on_platform": (None, "never")}
        response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = [] # output complessivo
        
        for page in response["document_pages"]:
            o = [] # output della singola pagina
            for field in response["service_fields"]:
                for entity in page["entities"]:
                    if field == entity and page["entities"][entity]:
                        for e in page["entities"][entity]:
                            o.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": e["text"], "confidence": e["confidence"]}) 
            output.append(o)

        output = [o for o in output if "Obis Mensilità" in [x["tipo"] for x in o]] # tengo solo le pagine con campo Obis Mensilità, che corrispondo quindi al dettaglio di una pensione

        return output
    else: return False

def estraiDatiObisM_b64(b64, estensione):
    """
    Estrae i dati presenti in un documento Obis M, a partire da una stringa in base64.

    :param str b64: stringa base64 del file
    :param str estensione: estensione del file
    :return: list con le pensioni presenti nel documento, False in caso di errore
    """

    url = f"https://platform.mybiros.com/api/v1/inference/service/5f6f8a6c-ac77-4044-9ec7-eb491ef95f15/predict"
    headers = {"x-api-key": "7qdVqGJWylEEUAW4KY9HbWkd3AKJ2VKeTF8DTvcW", "Accept": "application/json"}

    params = { # parametri delle chiamate API myBiros
        "include": ["service_fields"], # campi da includere nella risposta
        "document_details": "pages" # output diviso per pagina
    }

    file_bytes = base64.b64decode(b64)
    f = io.BytesIO(file_bytes)
    f.name = "documento." + estensione # necessario per farlo accettare come file

    files = {"file": (f.name, f, mimetype_file[estensione]),"push_result_on_platform": (None, "never")}
    response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = [] # output complessivo
        
        for page in response["document_pages"]:
            o = [] # output della singola pagina
            for field in response["service_fields"]:
                for entity in page["entities"]:
                    if field == entity and page["entities"][entity]:
                        for e in page["entities"][entity]:
                            o.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": e["text"], "confidence": e["confidence"]}) 
            output.append(o)

        output = [o for o in output if "Obis Mensilità" in [x["tipo"] for x in o]] # tengo solo le pagine con campo Obis Mensilità, che corrispondo quindi al dettaglio di una pensione

        return output
    else: return False


###   F U N Z I O N I   L E G A C Y   #################################
###   Utilizzate da alcuni programmi in produzione, da migrare

def estraiDatiBustaPaga(file, b64 = True):
    api_key = "oJBu6EAh--QZ450BuRY4WjvS1T57KP6YKkwv41wx"
    service_id = "cb2f96d2-a8f2-4538-bba3-363c0b74a0d4"
    url = f"https://platform.mybiros.com/api/v1/inference/service/{service_id}/predict"
    headers = {"x-api-key": api_key, "Accept": "application/json"}

    params = {"include": ["ocr", "service_fields"], "document_details": "summary"}

    if b64: # interpreto file come base64 (default)
        pdf_bytes = base64.b64decode(file)
        f = io.BytesIO(pdf_bytes)
        f.name = "documento.pdf" # necessario per farlo accettare come file
        files = {"file": ("file.pdf", f, "application/pdf"),"push_result_on_platform": (None, "never")}
        response = requests.post(url, headers=headers, params=params, files=files)
    else: # interpreto file come percorso
        with open(file, "rb") as f:
            files = {"file": (file, f, mimetypes.guess_type(file)[0]),"push_result_on_platform": (None, "never")}
            response = requests.post(url, headers=headers, params=params, files=files)

    if response.status_code == 200: 
        response = response.json(); output = []
    
        for field in response["service_fields"]:
            for entity in response["document_summary"]["entities"]:
                if field == entity and response["document_summary"]["entities"][entity]:
                    value = ""; confidence = 0
                    for e in response["document_summary"]["entities"][entity]:
                        if e["confidence"] > confidence: confidence = e["confidence"]; value = e["text"] # prendo il match con il valore più alto, ECCEZIONE PER CAMPI MULTIPLI?
                    output.append({"tipo": response["service_fields"][field]["tag_alias"], "valore": value, "confidence": str(confidence)})           
        return output
    else: return False

def estraiDatiDocumento(file, b64 = True):
    api_key = "CDtFLxF5SQ2geVwjMb8JQiUGVGgOeAUapz1fpc_4"
    service_id = "7471fd22-ee8d-4512-b77b-642dec127574"
    url = f"https://platform.mybiros.com/api/v1/inference/service/{service_id}/predict"
    headers = {"x-api-key": api_key, "Accept": "application/json"}

    params = {"include": ["ocr", "service_fields"], "document_details": "summary"}
    campiDocumento = {"Surname": "Cognome", "Name": "Nome", "Birth Date": "Data di Nascita", "Fiscal Code": "Codice Fiscale", "Sex": "Sesso", "Address": "Indirizzo", "Nationality": "Nazionalità", "Height": "Altezza", "ID Number": "Numero Documento"}

    if b64: # interpreto file come base64 (default)
        pdf_bytes = base64.b64decode(file)
        f = io.BytesIO(pdf_bytes)
        f.name = "documento.pdf" # necessario per farlo accettare come file
        files = {"file": ("file.pdf", f, "application/pdf"),"push_result_on_platform": (None, "never")}
    else: # interpreto file come percorso
        with open(file, "rb") as f:
            files = {"file": ("file.pdf", f, "application/pdf"),"push_result_on_platform": (None, "never")}

    response = requests.post(url, headers=headers, params=params, files=files)
    if response.status_code == 200: 
        response = response.json(); output = []
        print(response)
        for campo in campiDocumento:
            for field in response["service_fields"]:
                for entity in response["document_summary"]["entities"]:
                    if field == entity and response["document_summary"]["entities"][entity]["text"] and response["service_fields"][field]["tag_alias"] == campo:
                        output.append({"tipo": campiDocumento[response["service_fields"][field]["tag_alias"]], "valore": response["document_summary"]["entities"][entity]["text"]})
                    #elif field == entity and response["service_fields"][field]["tag_alias"] == "Category" and response["document_summary"]["entities"][entity]["text"] != "id_card":
                    #    return [{"tipo": "Documento Valido", "valore": "no"}]                
        return output
    else: return False

def estraiDatiObisM(file, b64 = True):
    api_key = "7qdVqGJWylEEUAW4KY9HbWkd3AKJ2VKeTF8DTvcW"
    service_id = "5f6f8a6c-ac77-4044-9ec7-eb491ef95f15"
    url = f"https://platform.mybiros.com/api/v1/inference/service/{service_id}/predict"
    headers = {"x-api-key": api_key, "Accept": "application/json"}
    params = {"include": ["service_fields"], "document_details": "summary"}

    if b64: # interpreto file come base64 (default)
        pdf_bytes = base64.b64decode(file)
        f = io.BytesIO(pdf_bytes)
        f.name = "documento.pdf" # necessario per farlo accettare come file
    else: # interpreto file come percorso
        f = open(file, "rb")

    files = {"file": ("file.pdf", f, "application/pdf"),"push_result_on_platform": (None, "never")}
    response = requests.post(url, headers=headers, params=params, files=files)
    if not b64: f.close()

    if response.status_code == 200: 
        response = response.json(); output = []
        print(response)
        for entity in response["document_summary"]["entities"]:
            output.append({"tipo": response["service_fields"][entity]["tag_alias"], "valore": response["document_summary"]["entities"][entity]})
        if output:
            for o in output:
                valori = []
                for v in o["valore"]:
                    if v["text"] not in valori: valori.append(v["text"])
                o["valore"] = valori
            return output
        else: return False
    else: return False


###   T E S T   #######################################################

#print(estraiDatiBustaPaga_file("bp1.pdf"))
#print(estraiDatiDocumento_file("10278006_DOCUMENTO.pdf"))